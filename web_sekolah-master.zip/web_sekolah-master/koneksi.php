<?php 
session_start();

$koneksi = mysqli_connect('localhost', 'root', '', 'sekolahku') or die('gagal konek');

?>