# Web Sekolah Sederhana Dengan PHP & MySQL 

### Kenapa saya membuat aplikasi ini?

Ini merupakan tugas sekolah yang akan saya jadikan sebagai portfolio. Sebenarnya saya sudah banyak membuat banyak aplikasi berbasi web, namun saya lupa membackupnya. Jadi saya harus mengulang lagi dari awal demi portfolio. Selain sebagai portfolio, contoh aplikasi ini juga bisa saya jadikan sebagai latihan untuk mengasah skill koding saya.

### Untuk siapa sih aplikasi ini?

Untuk kalian semua yang mau belajar atau yang butuh inspirasi tentang aplikasi berbasis web terutama yang menggunakan PHP dan MySQL.

### Boleh ga memodifikasi aplikasi ini?

Jawabanya adalah **sangat sangat boleh!** Tapi ingat tetap sertakan siapa yang membuat aplikasi ini. 

### Kalo di jual boleh ga?

**Dilarang Keras!** Karena ini aplikasi bener bener gratis dan bebas bagi siapapun yang menggunakan dan ingin memodifikasinya.

### Fiturnya apa saja sih?
Untuk fiturnya masih sangas sederhana, contohnya sebagai berikut
1. CRUD Artikel
2. CRUD Kategori Artikel
3. CRUD Data Guru
4. CRUD Data Jurusan
5. CRUD Data Siswa
6. CRUD Data Ekskul
7. Manajemen Akun
8. Buku Tamu**
9. dan lain lain


### Tentang Saya

Fakhrul Fanani Nugroho siswa Kelas 12 Jurusan Teknik Komputer Informatika di SMK Negeri 1 Wanareja. https://www.instagram.com/nugrohospace/
